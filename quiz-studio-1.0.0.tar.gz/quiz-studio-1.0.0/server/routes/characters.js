const express = require('express');
const router = express.Router();
const db = require('../models/database');

// Get all characters
router.get('/', async (req, res) => {
  try {
    const characters = await db.all(`
      SELECT c.*, cu.universe_name 
      FROM characters c 
      LEFT JOIN character_universes cu ON c.universe_id = cu.id 
      ORDER BY cu.universe_name, c.name
    `);
    res.json(characters);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get all universes
router.get('/universes', async (req, res) => {
  try {
    const universes = await db.all('SELECT * FROM character_universes ORDER BY universe_name');
    res.json(universes);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Add new universe
router.post('/universes', async (req, res) => {
  const { universe_name, description } = req.body;
  try {
    await db.run(
      'INSERT INTO character_universes (universe_name, description) VALUES (?, ?)',
      [universe_name, description]
    );
    res.json({ success: true, message: 'Universe added' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get characters by universe
router.get('/:universeId', async (req, res) => {
  const { universeId } = req.params;
  try {
    const characters = await db.all(
      'SELECT * FROM characters WHERE universe_id = ? ORDER BY name',
      [universeId]
    );
    res.json(characters);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Add new character
router.post('/', async (req, res) => {
  const { name, universe_id, emoji_icon, image_url } = req.body;
  try {
    await db.run(
      'INSERT INTO characters (name, universe_id, emoji_icon, image_url) VALUES (?, ?, ?, ?)',
      [name, universe_id, emoji_icon, image_url]
    );
    res.json({ success: true, message: 'Character added' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
