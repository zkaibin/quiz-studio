const express = require('express');
const router = express.Router();
const db = require('../models/database');

// Get all questions
router.get('/', async (req, res) => {
  try {
    const questions = await db.all('SELECT * FROM questions ORDER BY category, difficulty');
    res.json(questions);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get questions by category
router.get('/category/:category', async (req, res) => {
  const { category } = req.params;
  try {
    const questions = await db.all(
      'SELECT * FROM questions WHERE category = ? ORDER BY difficulty',
      [category]
    );
    res.json(questions);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Add new question
router.post('/', async (req, res) => {
  const { category, difficulty, template, placeholders, answer } = req.body;
  try {
    await db.run(
      'INSERT INTO questions (category, difficulty, template, placeholders, answer) VALUES (?, ?, ?, ?, ?)',
      [category, difficulty, template, JSON.stringify(placeholders), answer]
    );
    res.json({ success: true, message: 'Question added' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get categories
router.get('/categories', async (req, res) => {
  try {
    const categories = await db.all('SELECT DISTINCT category FROM questions');
    res.json(categories.map(c => c.category));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
