const express = require('express');
const router = express.Router();
const db = require('../models/database');

// Generate a quiz with random characters
router.post('/generate', async (req, res) => {
  const { category, difficulty, count = 5 } = req.body;
  try {
    // Get questions matching criteria
    let query = 'SELECT * FROM questions WHERE 1=1';
    const params = [];

    if (category && category !== 'all') {
      query += ' AND category = ?';
      params.push(category);
    }

    if (difficulty && difficulty !== 'all') {
      query += ' AND difficulty = ?';
      params.push(difficulty);
    }

    const questions = await db.all(query, params);

    if (questions.length === 0) {
      return res.status(400).json({ error: 'No questions found for criteria' });
    }

    // Get random characters
    const characters = await db.all('SELECT * FROM characters');

    if (characters.length === 0) {
      return res.status(400).json({ error: 'No characters in library' });
    }

    // Generate quiz
    const quiz = [];
    const selectedQuestions = selectRandom(questions, Math.min(count, questions.length));

    for (const question of selectedQuestions) {
      const placeholders = JSON.parse(question.placeholders || '[]');
      
      // Count only character placeholders (those that start with 'character')
      const charPlaceholders = placeholders.filter(p => p.includes('character'));
      const selectedChars = selectRandom(characters, Math.min(charPlaceholders.length, characters.length));
      
      let generatedQuestion = question.template;
      let charIndex = 0;
      const numberValues = {}; // Track generated numbers for answer calculation

      // Replace all placeholders
      placeholders.forEach((placeholder) => {
        let replacement;
        if (placeholder.includes('character')) {
          // Use a character if available
          if (charIndex < selectedChars.length) {
            replacement = selectedChars[charIndex].name;
            charIndex++;
          } else {
            replacement = selectedChars[0].name; // fallback
          }
        } else if (placeholder.includes('num')) {
          // Use a random number
          replacement = Math.floor(Math.random() * 10) + 1;
          numberValues[placeholder] = replacement; // Store for calculation
        } else {
          // Generic replacement
          replacement = placeholder;
        }
        
        const regex = new RegExp(`\\{${placeholder}\\}`, 'g');
        generatedQuestion = generatedQuestion.replace(regex, replacement);
      });

      // Calculate the correct answer based on category and numbers
      const calculatedAnswer = calculateAnswer(question.category, question.template, numberValues, placeholders);

      quiz.push({
        id: question.id,
        category: question.category,
        difficulty: question.difficulty,
        question: generatedQuestion,
        answer: calculatedAnswer,
        characters_used: selectedChars.map(c => ({ name: c.name, emoji: c.emoji_icon }))
      });
    }

    res.json(quiz);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Save quiz session result
router.post('/session', async (req, res) => {
  const { student_name, score, total_questions } = req.body;
  try {
    await db.run(
      'INSERT INTO quiz_sessions (student_name, score, total_questions) VALUES (?, ?, ?)',
      [student_name, score, total_questions]
    );
    res.json({ success: true, message: 'Quiz session saved' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get quiz history
router.get('/history', async (req, res) => {
  try {
    const history = await db.all(
      'SELECT * FROM quiz_sessions ORDER BY timestamp DESC LIMIT 50'
    );
    res.json(history);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Calculate the correct answer based on category and numbers
function calculateAnswer(category, template, numberValues, placeholders) {
  // Extract numeric values in order from numberValues
  const nums = [];
  placeholders.forEach(p => {
    if (p.includes('num') && numberValues[p] !== undefined) {
      nums.push(numberValues[p]);
    }
  });

  if (nums.length === 0) {
    return 0; // No numbers found
  }

  switch (category) {
    case 'addition':
      // Sum all numbers
      return nums.reduce((a, b) => a + b, 0);
    
    case 'subtraction':
      // Start with first number and subtract rest
      return nums.reduce((a, b) => a - b);
    
    case 'multiplication':
      // Multiply all numbers
      return nums.reduce((a, b) => a * b, 1);
    
    case 'division':
      // Divide first by second (integer division)
      return Math.floor(nums[0] / nums[1]);
    
    case 'mixed':
      // For mixed operations, check template for operation clues
      if (template.includes('bought') && template.includes('spent')) {
        // Likely multiplication + addition
        // Assume pattern: (num1 * num2) + (num3 * num4)
        if (nums.length === 4) {
          return (nums[0] * nums[1]) + (nums[2] * nums[3]);
        }
      } else if (template.includes('bought') && template.includes('shared')) {
        // Addition then division
        // (num1 + num2) / num3
        if (nums.length === 3) {
          return Math.floor((nums[0] + nums[1]) / nums[2]);
        }
      }
      // Default fallback
      return nums.reduce((a, b) => a + b, 0);
    
    default:
      return 0;
  }
}

function selectRandom(arr, count) {
  const shuffled = [...arr].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
}

module.exports = router;
