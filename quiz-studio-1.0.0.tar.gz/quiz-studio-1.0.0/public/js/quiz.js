class QuizApp {
  constructor() {
    this.questions = [];
    this.answers = [];
    this.studentName = '';
    this.score = 0;
    this.category = '';
    this.difficulty = '';
    this.letters = ['A', 'B', 'C', 'D'];

    this.setupEventListeners();
  }

  setupEventListeners() {
    document.getElementById('startQuizBtn').addEventListener('click', () => this.startQuiz());
    document.getElementById('submitBtn').addEventListener('click', () => this.finishQuiz());
    document.getElementById('printBtn').addEventListener('click', () => this.printQuiz());
    document.getElementById('retakeQuizBtn').addEventListener('click', () => this.reset());
    document.getElementById('adminBtn').addEventListener('click', () => {
      window.location.href = '/admin';
    });
  }

  async startQuiz() {
    const studentName = document.getElementById('studentName').value.trim();
    const category = document.getElementById('category').value;
    const difficulty = document.getElementById('difficulty').value;
    const questionCount = document.getElementById('questionCount').value;

    if (!studentName) {
      alert('Please enter your name!');
      return;
    }

    this.studentName = studentName;
    this.category = category;
    this.difficulty = difficulty;

    try {
      const response = await fetch('/api/quiz/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          category,
          difficulty,
          count: parseInt(questionCount)
        })
      });

      if (!response.ok) {
        const error = await response.json();
        alert('Error: ' + error.error);
        return;
      }

      this.questions = await response.json();

      if (this.questions.length === 0) {
        alert('No questions available for this criteria');
        return;
      }

      this.answers = new Array(this.questions.length).fill(null);
      this.score = 0;

      this.showQuizSection();
      this.displayAllQuestions();
    } catch (err) {
      alert('Error generating quiz: ' + err.message);
    }
  }

  displayAllQuestions() {
    const container = document.getElementById('questionContainer');
    let html = '';

    // Update header info
    document.getElementById('studentNameDisplay').textContent = `Student: ${this.studentName}`;
    document.getElementById('quizCategoryDisplay').textContent = 
      `Category: ${this.category === 'all' ? 'All Categories' : this.category.charAt(0).toUpperCase() + this.category.slice(1)}`;
    document.getElementById('quizDifficultyDisplay').textContent = 
      `Level: ${this.difficulty === 'all' ? 'All Levels' : this.difficulty.charAt(0).toUpperCase() + this.difficulty.slice(1)}`;

    // Generate HTML for all questions
    this.questions.forEach((question, index) => {
      const options = this.generateOptions(question.answer);
      const isAnswered = this.answers[index] !== null;

      html += `
        <div class="question-item" data-question-index="${index}">
          <div class="question-number">Question ${index + 1}</div>
          <div class="question-text">${question.question}</div>
          <div class="question-options">
      `;

      // Add options with A/B/C/D labels
      options.forEach((option, optionIndex) => {
        const letter = this.letters[optionIndex];
        const isSelected = this.answers[index] === option;
        const isCorrect = option === question.answer;
        let classNames = 'option-item';

        if (isAnswered) {
          if (isSelected && isCorrect) {
            classNames += ' selected correct';
          } else if (isSelected && !isCorrect) {
            classNames += ' selected incorrect';
          } else if (!isSelected && isCorrect) {
            classNames += ' correct';
          }
        } else if (isSelected) {
          classNames += ' selected';
        }

        html += `
          <div class="${classNames}" data-question-index="${index}" data-answer="${option}">
            <div class="option-letter">${letter}</div>
            <div class="option-text">${option}</div>
          </div>
        `;
      });

      html += `
          </div>
        </div>
      `;
    });

    container.innerHTML = html;

    // Use event delegation for better performance and to avoid memory leaks
    // Remove old listener if it exists
    if (this.optionClickHandler) {
      container.removeEventListener('click', this.optionClickHandler);
    }

    // Create handler function that uses event delegation
    this.optionClickHandler = (e) => {
      if (e.target.closest('.option-item')) {
        const optionItem = e.target.closest('.option-item');
        const questionIndex = parseInt(optionItem.getAttribute('data-question-index'));
        const answer = parseInt(optionItem.getAttribute('data-answer'));
        this.selectAnswer(questionIndex, answer);
      }
    };

    // Attach single delegated listener to container
    container.addEventListener('click', this.optionClickHandler);
  }

  generateOptions(correctAnswer) {
    const options = [correctAnswer];
    
    // Generate 3 wrong answers that are reasonable but different
    const wrongAnswers = new Set();
    
    while (wrongAnswers.size < 3) {
      let wrong;
      
      // Generate realistic wrong answers
      const offset = Math.floor(Math.random() * 4) + 1; // offset 1-4
      const wrongTry = correctAnswer + (Math.random() > 0.5 ? offset : -offset);
      
      // Make sure it's not the correct answer and not already generated
      if (wrongTry !== correctAnswer && wrongTry >= 0 && !wrongAnswers.has(wrongTry)) {
        wrongAnswers.add(wrongTry);
      }
    }
    
    options.push(...Array.from(wrongAnswers));
    
    // Shuffle options
    return options.sort(() => Math.random() - 0.5);
  }

  selectAnswer(questionIndex, answer) {
    const oldAnswer = this.answers[questionIndex];
    this.answers[questionIndex] = answer;
    
    // Update UI for this question
    const questionElements = document.querySelectorAll(`[data-question-index="${questionIndex}"]`);
    questionElements.forEach(el => {
      if (el.classList.contains('option-item')) {
        el.classList.remove('selected', 'correct', 'incorrect');
        
        const optionAnswer = parseInt(el.getAttribute('data-answer'));
        const correctAnswer = this.questions[questionIndex].answer;

        if (optionAnswer === answer) {
          el.classList.add('selected');
        }
      }
    });

    // Recalculate score
    this.score = 0;
    this.answers.forEach((ans, idx) => {
      if (ans === this.questions[idx].answer) {
        this.score++;
      }
    });
  }

  printQuiz() {
    window.print();
  }

  async finishQuiz() {
    // Calculate score
    this.score = 0;
    this.answers.forEach((ans, idx) => {
      if (ans === this.questions[idx].answer) {
        this.score++;
      }
    });

    const percentage = Math.round((this.score / this.questions.length) * 100);

    // Save session
    try {
      await fetch('/api/quiz/session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          student_name: this.studentName,
          score: this.score,
          total_questions: this.questions.length
        })
      });
    } catch (err) {
      console.error('Error saving session:', err);
    }

    // Show results
    document.getElementById('finalScore').textContent = this.score;
    document.getElementById('totalQuestions').textContent = this.questions.length;
    document.getElementById('scorePercentage').textContent = percentage + '%';

    let message = '';
    if (percentage === 100) {
      message = '🌟 Perfect Score! You\'re a math wizard!';
    } else if (percentage >= 80) {
      message = '🎉 Great job! You did excellent!';
    } else if (percentage >= 60) {
      message = '👍 Good effort! Keep practicing!';
    } else {
      message = '💪 Don\'t give up! Practice makes perfect!';
    }

    document.getElementById('resultMessage').textContent = message;

    this.showResultsSection();
  }

  showQuizSection() {
    document.getElementById('setupSection').classList.add('hidden');
    document.getElementById('quizSection').classList.remove('hidden');
    document.getElementById('resultsSection').classList.add('hidden');
  }

  showResultsSection() {
    document.getElementById('setupSection').classList.add('hidden');
    document.getElementById('quizSection').classList.add('hidden');
    document.getElementById('resultsSection').classList.remove('hidden');
  }

  reset() {
    document.getElementById('setupSection').classList.remove('hidden');
    document.getElementById('quizSection').classList.add('hidden');
    document.getElementById('resultsSection').classList.add('hidden');
    document.getElementById('studentName').value = '';
    
    // Clean up event listeners
    const container = document.getElementById('questionContainer');
    if (this.optionClickHandler && container) {
      container.removeEventListener('click', this.optionClickHandler);
      this.optionClickHandler = null;
    }
    
    this.questions = [];
    this.answers = [];
    this.studentName = '';
    this.score = 0;
    this.category = '';
    this.difficulty = '';
  }
}

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  window.quizApp = new QuizApp();
});
