class AdminApp {
  constructor() {
    this.universes = [];
    this.characters = [];
    this.questions = [];
    this.sessions = [];

    this.setupEventListeners();
    this.loadData();
  }

  setupEventListeners() {
    // Navigation
    document.querySelectorAll('.nav-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        if (!btn.classList.contains('nav-link')) {
          this.switchSection(btn.dataset.section);
        }
      });
    });

    // Universe form
    document.getElementById('addUniverseBtn').addEventListener('click', () => this.addUniverse());

    // Character form
    document.getElementById('addCharacterBtn').addEventListener('click', () => this.addCharacter());

    // Question form
    document.getElementById('addQuestionBtn').addEventListener('click', () => this.addQuestion());

    // Enter key in inputs
    document.getElementById('universeName').addEventListener('keypress', (e) => {
      if (e.key === 'Enter') this.addUniverse();
    });
  }

  switchSection(sectionName) {
    document.querySelectorAll('.admin-section').forEach(section => {
      section.classList.remove('active');
    });
    document.getElementById(sectionName + 'Section').classList.add('active');

    document.querySelectorAll('.nav-btn').forEach(btn => {
      btn.classList.remove('active');
    });
    event.target.classList.add('active');

    if (sectionName === 'stats') {
      this.loadStats();
    }
  }

  async loadData() {
    try {
      const [universesRes, charactersRes, questionsRes, sessionsRes] = await Promise.all([
        fetch('/api/characters/universes'),
        fetch('/api/characters'),
        fetch('/api/questions'),
        fetch('/api/quiz/history')
      ]);

      this.universes = await universesRes.json();
      this.characters = await charactersRes.json();
      this.questions = await questionsRes.json();
      this.sessions = await sessionsRes.json();

      this.renderUniverses();
      this.renderCharacters();
      this.renderQuestions();
      this.updateCharacterUniverse();
    } catch (err) {
      console.error('Error loading data:', err);
    }
  }

  async addUniverse() {
    const name = document.getElementById('universeName').value.trim();
    const desc = document.getElementById('universeDesc').value.trim();

    if (!name) {
      alert('Please enter a universe name');
      return;
    }

    try {
      const response = await fetch('/api/characters/universes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          universe_name: name,
          description: desc
        })
      });

      if (response.ok) {
        document.getElementById('universeName').value = '';
        document.getElementById('universeDesc').value = '';
        this.loadData();
        alert('Universe added successfully!');
      }
    } catch (err) {
      alert('Error adding universe: ' + err.message);
    }
  }

  async addCharacter() {
    const name = document.getElementById('characterName').value.trim();
    const universeId = document.getElementById('characterUniverse').value;
    const emoji = document.getElementById('characterEmoji').value.trim();
    const imageUrl = document.getElementById('characterImage').value.trim();

    if (!name || !universeId) {
      alert('Please fill in required fields');
      return;
    }

    try {
      const response = await fetch('/api/characters', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          universe_id: parseInt(universeId),
          emoji_icon: emoji,
          image_url: imageUrl
        })
      });

      if (response.ok) {
        document.getElementById('characterName').value = '';
        document.getElementById('characterEmoji').value = '';
        document.getElementById('characterImage').value = '';
        this.loadData();
        alert('Character added successfully!');
      }
    } catch (err) {
      alert('Error adding character: ' + err.message);
    }
  }

  async addQuestion() {
    const category = document.getElementById('qCategory').value;
    const difficulty = document.getElementById('qDifficulty').value;
    const template = document.getElementById('qTemplate').value.trim();
    const placeholdersStr = document.getElementById('qPlaceholders').value.trim();
    const answer = parseInt(document.getElementById('qAnswer').value);

    if (!template || !placeholdersStr || !answer) {
      alert('Please fill in all required fields');
      return;
    }

    const placeholders = placeholdersStr.split(',').map(p => p.trim());

    try {
      const response = await fetch('/api/questions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          category,
          difficulty,
          template,
          placeholders,
          answer
        })
      });

      if (response.ok) {
        document.getElementById('qTemplate').value = '';
        document.getElementById('qPlaceholders').value = '';
        document.getElementById('qAnswer').value = '';
        this.loadData();
        alert('Question added successfully!');
      }
    } catch (err) {
      alert('Error adding question: ' + err.message);
    }
  }

  renderUniverses() {
    const container = document.getElementById('universesList');
    if (this.universes.length === 0) {
      container.innerHTML = '<p style="color: #999;">No universes yet. Add one above!</p>';
      return;
    }

    container.innerHTML = this.universes.map(u => `
      <div class="list-item">
        <div class="list-item-content">
          <h4>${u.universe_name}</h4>
          <p>${u.description || 'No description'}</p>
        </div>
      </div>
    `).join('');
  }

  renderCharacters() {
    const container = document.getElementById('charactersList');
    if (this.characters.length === 0) {
      container.innerHTML = '<p style="color: #999;">No characters yet. Add one above!</p>';
      return;
    }

    // Group by universe
    const grouped = {};
    this.characters.forEach(c => {
      const universe = c.universe_name || 'Unknown';
      if (!grouped[universe]) grouped[universe] = [];
      grouped[universe].push(c);
    });

    container.innerHTML = Object.entries(grouped).map(([universe, chars]) => `
      <div>
        <h4 style="color: var(--primary-color); margin: 15px 0 10px 0;">${universe}</h4>
        ${chars.map(c => `
          <div class="list-item">
            <div class="list-item-content">
              <h4>${c.emoji_icon || '👤'} ${c.name}</h4>
            </div>
          </div>
        `).join('')}
      </div>
    `).join('');
  }

  renderQuestions() {
    const container = document.getElementById('questionsList');
    if (this.questions.length === 0) {
      container.innerHTML = '<p style="color: #999;">No questions yet. Add one above!</p>';
      return;
    }

    container.innerHTML = this.questions.map(q => `
      <div class="list-item">
        <div class="list-item-content">
          <h4>${q.category.toUpperCase()}</h4>
          <p>${q.template.substring(0, 100)}...</p>
        </div>
        <div class="list-item-meta">
          <span class="badge">${q.difficulty}</span>
          <span class="badge badge-secondary">Answer: ${q.answer}</span>
        </div>
      </div>
    `).join('');
  }

  updateCharacterUniverse() {
    const select = document.getElementById('characterUniverse');
    select.innerHTML = this.universes.map(u => 
      `<option value="${u.id}">${u.universe_name}</option>`
    ).join('');
  }

  async loadStats() {
    // Update counts
    document.getElementById('totalQuestions').textContent = this.questions.length;
    document.getElementById('totalCharacters').textContent = this.characters.length;
    document.getElementById('totalUniverses').textContent = this.universes.length;
    document.getElementById('totalSessions').textContent = this.sessions.length;

    // Render sessions
    const container = document.getElementById('sessionsList');
    if (this.sessions.length === 0) {
      container.innerHTML = '<p style="color: #999;">No quiz sessions yet.</p>';
      return;
    }

    container.innerHTML = this.sessions.map(s => `
      <div class="session-item">
        <div class="session-info">
          <span class="session-name">${s.student_name || 'Anonymous'}</span>
          <span class="session-time">${new Date(s.timestamp).toLocaleDateString()} ${new Date(s.timestamp).toLocaleTimeString()}</span>
        </div>
        <div class="session-score">
          ${s.score}/${s.total_questions}
        </div>
        <div style="text-align: center; font-weight: 600;">
          ${Math.round((s.score / s.total_questions) * 100)}%
        </div>
      </div>
    `).join('');
  }
}

// Initialize admin app
document.addEventListener('DOMContentLoaded', () => {
  window.adminApp = new AdminApp();
});
